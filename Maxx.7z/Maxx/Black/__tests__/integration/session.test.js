describe ("Authentication", () => {
    it("shloud sum two numbers", () => {
        const x = 2
        const y = 4

        const sum = x + y

        expect(sum).toBe(6)
    })
})